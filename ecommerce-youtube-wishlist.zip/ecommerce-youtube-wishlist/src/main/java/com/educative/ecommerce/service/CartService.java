package com.educative.ecommerce.service;

import com.educative.ecommerce.dto.cart.AddToCartDto;
import com.educative.ecommerce.dto.cart.CartListDto;
import com.educative.ecommerce.dto.cart.ProductDescriptionDto;
import com.educative.ecommerce.exceptions.CustomException;
import com.educative.ecommerce.model.Cart;
import com.educative.ecommerce.model.Product;
import com.educative.ecommerce.model.User;
import com.educative.ecommerce.repository.CartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class CartService {
    @Autowired

    private ProductService productService;
    @Autowired
private  CartRepository cartRepository;



    public void addTocart(AddToCartDto addToCartDto, User user) {
        // check whether id is valid or not
    Product product=    productService.findById(addToCartDto.getProductId());

        ProductDescriptionDto productDescriptionDto=findall(user);

        List<CartListDto> cartListDtoList =productDescriptionDto.getCartListDtoList();
        boolean isPresent=false;
        for(CartListDto cartListDto:cartListDtoList){
            if(cartListDto.getProduct()==product){
                isPresent=true;
            }
        }
    Cart cart =new Cart(product,user,addToCartDto.getQuantity());
        if(!isPresent) {
            cartRepository.save(cart);
        }
        else{
            throw new CustomException("product is already added to cart:"+product.getId());
        }
        // Save the product
    }

    public ProductDescriptionDto findall(User user) {
        List<Cart> cartList=getAllProducts(user);

        List<CartListDto> cartListDtoList=new ArrayList<>();
        double total=0.0;
        for(Cart cart:cartList){
            cartListDtoList.add( new CartListDto(cart.getId(),cart.getProduct(),cart.getQuantity()));
            total=total+ cart.getProduct().getPrice()*cart.getQuantity();
        }
        System.out.println(cartListDtoList);


        ProductDescriptionDto productDescriptionDto=new ProductDescriptionDto(cartListDtoList,total);

        return productDescriptionDto;
    }
    public List<Cart> getAllProducts(User user){
        return  cartRepository.findAllByUserOrderByDateDesc(user);
    }

    public void deleteCartItem(User user, Integer cartItemId) {
        Optional<Cart> OptionalCart=cartRepository.findById(cartItemId);
        if(OptionalCart.isEmpty()){
            throw new CustomException("cart item is empty for cart Item id"+cartItemId);
        }
        Cart cart=OptionalCart.get();
        if(cart.getUser()!=user){
            throw new CustomException("cart item does not belongs to the user");
        }
        cartRepository.delete(cart);

    }

}
