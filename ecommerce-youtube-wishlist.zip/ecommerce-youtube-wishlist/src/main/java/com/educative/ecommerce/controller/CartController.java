package com.educative.ecommerce.controller;

import com.educative.ecommerce.common.ApiResponse;
import com.educative.ecommerce.dto.cart.AddToCartDto;
import com.educative.ecommerce.dto.cart.ProductDescriptionDto;
import com.educative.ecommerce.model.Cart;
import com.educative.ecommerce.model.User;
import com.educative.ecommerce.service.AuthenticationService;
import com.educative.ecommerce.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/cart")
public class CartController {
    @Autowired
    private CartService cartService;
    @Autowired
    private AuthenticationService authenticationService;

    // we have post the cart api
    @PostMapping
public ResponseEntity<ApiResponse> addToCart(@RequestBody AddToCartDto addToCartDto, @RequestParam("token") String token) {
    //get all items for the particular items
    authenticationService.authenticate(token);
    User user=authenticationService.getUser(token);
    cartService.addTocart(addToCartDto,user);
    // Delete the cart items
    return new  ResponseEntity<>(new ApiResponse(true,"Success"), HttpStatus.CREATED);
}
@GetMapping("/product/user")
public ResponseEntity<ProductDescriptionDto> getALlCartItems(@RequestParam("token") String token){
    authenticationService.authenticate(token);
    User user=authenticationService.getUser(token);
        ProductDescriptionDto cartList=cartService.findall(user);
        return new ResponseEntity<>(cartList,HttpStatus.OK);
}
@DeleteMapping("/delete/{cartItemId}")
public ResponseEntity<ApiResponse> deleteCartItem(@PathVariable("cartItemId") Integer cartItemId,@RequestParam("token") String token){
    authenticationService.authenticate(token);
    User user=authenticationService.getUser(token);

    cartService.deleteCartItem(user,cartItemId);
    return new ResponseEntity<>(new ApiResponse(true,"cart item is successfully deleted"),HttpStatus.OK);
}
}
