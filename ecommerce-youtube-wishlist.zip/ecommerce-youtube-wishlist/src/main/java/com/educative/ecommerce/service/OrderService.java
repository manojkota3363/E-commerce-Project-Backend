package com.educative.ecommerce.service;

import org.springframework.stereotype.Service;

@Service
public class OrderService {
}
