package com.educative.ecommerce.dto.cart;

import java.util.List;


public class ProductDescriptionDto {

    List<CartListDto> cartListDtoList;
    private Double totalPrice;

    public ProductDescriptionDto(List<CartListDto> cartListDtoList, Double totalPrice) {
        this.cartListDtoList = cartListDtoList;
        this.totalPrice = totalPrice;
    }
public ProductDescriptionDto(){


}


    public List<CartListDto> getCartListDtoList() {
        return cartListDtoList;
    }

    public void setCartListDtoList(List<CartListDto> cartListDtoList) {
        this.cartListDtoList = cartListDtoList;
    }

    public Double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
    }
}
