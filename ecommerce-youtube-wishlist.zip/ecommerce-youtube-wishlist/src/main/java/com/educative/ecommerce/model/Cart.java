package com.educative.ecommerce.model;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name="cart")
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
@Column(name="created_date")
    private Date date;


@ManyToOne(targetEntity = Product.class, fetch = FetchType.EAGER)
@JoinColumn(name = "product_id")
private Product product;

@ManyToOne(targetEntity = User.class, fetch = FetchType.EAGER)
@JoinColumn(name = "user_id")
private User user;

private int quantity;

public Cart(){

}

    public Cart(Product product, User user, int quantity) {
        this.product = product;
        this.user = user;
        this.quantity = quantity;
        this.date=new Date();
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }


}
